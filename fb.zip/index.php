<html>
<head>
    <title>
        Test FB images
    </title>

</head>
<body>
<?php
include_once 'FacebookAlbums.php';
$fb = new FacebokAlbums();
$fb->getAlbumImages('314854078551721_67268',14,100, true);
//$fb->getAlbumImages('314854078551721_73682',12,150);
//$fb->getAlbumImages('314854078551721_73686',11,70);
//$fb->getAlbumImages('314854078551721_85389',10,90);
//$fb->getAlbumImages('314854078551721_67268',9);
//echo $fb->getUserAlbumList();
?>
</body>
</html>
